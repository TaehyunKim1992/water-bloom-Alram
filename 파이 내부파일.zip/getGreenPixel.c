#include <stdio.h>
#include <malloc.h>

#define HEADER_SIZE 54
#define ROW_PADDING 4
#define BYTES_PER_PIXEL 3

#define lsb32(p) (((int32_t)(p)[0] & 0xff) | \
                   ((int32_t)(p)[1] & 0xff) << 8 | \
                   ((int32_t)(p)[2] & 0xff) << 16 | \
                   ((int32_t)(p)[2] & 0xff) << 24)

typedef char int8_t;
typedef short int16_t;
typedef long int32_t;

int main()
{
    FILE* fp;
    FILE* txt;
    int8_t header[HEADER_SIZE];
    int8_t* data;
    int32_t data_len;
    int32_t width, height;
    int bytes_per_row;
    int x, y;
    int count=0;
    double per=0;

    fp = fopen("/home/pi/www/final.bmp", "rb");
    fread((char*)header, sizeof(int8_t), HEADER_SIZE, fp);
    data_len = lsb32(header + 2) - HEADER_SIZE;
    data = (int8_t *)malloc(sizeof(int8_t) * data_len);
    fread((char*)data, sizeof(int8_t), data_len, fp);
    fclose(fp);
    width = lsb32(header + 18);
    height = lsb32(header + 22);
    bytes_per_row =
        ((width * BYTES_PER_PIXEL - 1) / ROW_PADDING + 1) * ROW_PADDING;
    for (y = 0; y < height; ++y)
    {
        int index_base = y * bytes_per_row;
        for (x = 0; x < width; ++x)
        {
        int32_t pixel = lsb32(data+(y*bytes_per_row)+(x*BYTES_PER_PIXEL));

        int r = (pixel >> 16 ) & 0xff;
        int g = (pixel >> 8 ) & 0xff;
        int b = pixel & 0xff;
        double h=0,delta=0;
        int max,min;


        if(r<g) min = r;
        else min = g;

        if(min<b) min = min;
        else min = b;

        if(r>g) max = r;
        else max = g;

        if(max>b) max=max;
        else max = b;
        delta = max - min;

        if(r >= max)
        h = (g-b)/delta;
        else if(g >= max)
        h = 2.0 + (b-r)/delta;
        else
        h = 4.0 + (r-g)/delta;

        h = h*60;

        if(h<0.0)
        h = h + 360.0;

        printf("X: %d y: %d  R,G,B:%d,%d,%d   Hue:%f \n",x,y,r,g,b,h);

        if(60 < h){
        if(h < 140)count++;
        }
    }
}

	char ex;
        per = ((double)count/(double)(width*height))*100;
        printf("Result....: %f   count:%d pixel:%d \n",per,count,width*height);
	txt = fopen("result.txt","w");
	fprintf(txt,"%f",per);
	fclose(txt);

	    free(data);
    return 0;
}

