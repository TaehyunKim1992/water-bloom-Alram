echo "Start SmartNEMO"

for i in $(seq 1 1000)
do

echo "take a picture"

sleep 1

raspistill --width 240 --height 180 --awb sun --encoding bmp -o /home/pi/www/final.bmp 

sleep 1

echo "analysis....."

sleep 1

sudo ./aaaaa2

echo "temperature measurement....."

sleep 2

sudo python ds18b20.py

done

