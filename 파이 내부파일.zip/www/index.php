﻿<?
$fp = fopen("../result.txt","r"); // text.txt파일을 한 줄씩 읽습니다.
 if(!$fp) { // $fp파일이 없으면 에러 출력
 echo "error";
 }
 while(!feof($fp)) { //문자의 마지막 행까지 간다
 $str = fgets($fp,10000); // 10000길이까지 읽어드리지만 중간에 개행문자가 있으면 알아서 멈춘다.
 $arr[] = $str; // $arr배열에 하나씩 넣는다. $b[1] = "첫번째 줄" 뭐 이런식
 }
 for($i=0;$i<sizeof($arr);$i++) { // 행만큼돌려준다.
 $nuk[] = $arr[$i]; //nuk에 배열을 넣어준다.
 }
  header ("Content-Type:text/xml"); 
   
  $xml = new SimpleXMLElement("<result></result>"); 
  $xml->addAttribute('id', '1'); 
  for($j=0;$j<sizeof($nuk);$j++){
  $state=$xml->addChild('state'); 
  if($nuk[$j] >= 70){
		$state->addChild('stvalue', $nuk[$j]);
		$state->addChild('stname',  '위험');
  }
  elseif(40 <= $nuk[$j] && $nuk[$j] < 70){
		$state->addChild('stvalue', $nuk[$j]);
		$state->addChild('stname',  '경고');
  }
  elseif(15 <= $nuk[$j] && $nuk[$j] < 40){
		$state->addChild('stvalue', $nuk[$j]); 
		$state->addChild('stname',  '주의');  
  }
  else{
		$state->addChild('stvalue', $nuk[$j]); 
		$state->addChild('stname',  '양호');  
  }
 }

fclose($fp);

$fo = fopen("../temp.txt","r"); // temp.txt파일을 한 줄씩 읽습니다.
 if(!$fo) { // $fo파일이 없으면 에러 출력
 echo "error";
 }
 while(!feof($fo)) { //문자의 마지막 행까지 간다
 $str1 = fgets($fo,10000); // 10000길이까지 읽어드리지만 중간에 개행문자가 있으면 알아서 멈춘다.
 $arr1[] = $str1; // $arr1배열에 하나씩 넣는다. $b[1] = "첫번째 줄" 뭐 이런식
 }
 for($l=0;$l<sizeof($arr1);$l++) { // 행만큼돌려준다.
 $nuk1[] = $arr1[$l]; //nuk1에 배열을 넣어준다.
 }
  
   for($k=0;$k<sizeof($nuk1);$k++){ 
    if($nuk1[$k] < 40 && $nuk1[$k] !="") // 널값과 화씨(℉)값은 제외시킨다
    $state->addChild('tmvalue', $nuk1[$k]);
  }
  echo $xml->asXML();

fclose($fo);

?>