<? 
flush(); 
ob_flush(); 
echo "�۾���..<br />\n";

for($i=0; $i<255; $i++) 
{ 
/* 
ó�� �۾� �ڵ� 
*/ 	$nuk = mt_rand(1, 255);

	if($nuk >= 200){
	        echo "$nuk ����!!!<br />\n";
	}
	elseif(100 <= $nuk && $nuk < 200){
		echo "$nuk ����! <br />\n";
	}
	else{
		echo "$nuk ��ȣ~ <br />\n";
	}
        flush(); 
        ob_flush();
	usleep(2000000);
        ob_end_flush(); 
} 
?> 
