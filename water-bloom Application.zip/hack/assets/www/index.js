function init() {
    document.addEventListener("deviceready", onDeviceReady, true);
}   

$(document).ready(function() {
        var url = "http://172.17.15.206"
        $.ajax({
             type: "GET",             
             url: url,
             data: "{}",
             cache: false,
             dataType: "xml",
             success: hack
           });
});
function hack(data)
{   
       $("#pag1").text("");
       $(data).find("state").each(function () {
           $("#pag1").append("<li>" + $(this).find("stvalue").text() +$(this).find("stname").text()  +"</li>");
           $("#pag1").listview("refresh");     
       });
}